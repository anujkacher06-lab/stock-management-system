function makePrediction() {
  const gender = parseInt(document.getElementById('gender').value);
  const married = parseInt(document.getElementById('married').value);
  const dependents = parseInt(document.getElementById('dependents').value);
  const education = parseInt(document.getElementById('education').value);
  const selfEmployed = parseInt(document.getElementById('selfEmployed').value);
  const applicantIncome = parseFloat(document.getElementById('applicantIncome').value);
  const coapplicantIncome = parseFloat(document.getElementById('coapplicantIncome').value);
  const loanAmount = parseFloat(document.getElementById('loanAmount').value);
  const loanTerm = parseFloat(document.getElementById('loanTerm').value);
  const creditHistory = parseInt(document.getElementById('creditHistory').value);
  const propertyArea = parseInt(document.getElementById('propertyArea').value);

  // New inputs
  const monthlyDebt = parseFloat(document.getElementById('monthlyDebt').value);
  const employmentLength = parseInt(document.getElementById('employmentLength').value);
  const propertyValue = parseFloat(document.getElementById('propertyValue').value);

  // Validate essential inputs
  if (isNaN(applicantIncome) || isNaN(loanAmount) || isNaN(monthlyDebt) || isNaN(employmentLength) || isNaN(propertyValue)) {
    alert("⚠️ Please enter valid numbers in all required fields.");
    return;
  }

  const totalIncome = applicantIncome + (coapplicantIncome || 0);
  const dti = monthlyDebt / applicantIncome;  // Debt-to-Income ratio
  const ltv = loanAmount / propertyValue;     // Loan-to-Value ratio

  let prediction = "❌ Not Eligible";
  let isEligible = false;

  if (
    creditHistory === 1 &&
    totalIncome > 3000 &&
    loanAmount <= 250 &&
    dti < 0.4 &&
    ltv < 0.8 &&
    employmentLength >= 2
  ) {
    isEligible = true;
  } else if (
    creditHistory === 1 &&
    totalIncome > 5000 &&
    loanAmount <= 350 &&
    dti < 0.35 &&
    ltv < 0.75 &&
    employmentLength >= 3
  ) {
    isEligible = true;
  }

  const resultDiv = document.getElementById("predictionResult");
  if (isEligible) {
    resultDiv.innerHTML = `<div class="result-box"><strong>Prediction Result:</strong> ✅ Eligible for Loan</div>`;
  } else {
    resultDiv.innerHTML = `<div class="result-box not-eligible"><strong>Prediction Result:</strong> ❌ Not Eligible for Loan</div>`;
  }
}
