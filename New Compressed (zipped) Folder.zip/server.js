import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public")); // to serve your HTML

app.post("/predict", (req, res) => {
  const {
    gender, married, dependents, education, selfEmployed,
    applicantIncome, coapplicantIncome, loanAmount, loanTerm,
    creditHistory, propertyArea
  } = req.body;

  const totalIncome = applicantIncome + coapplicantIncome;
  let prediction = "❌ Not Eligible";

  if (creditHistory === 1 && totalIncome > 3000 && loanAmount <= 250) {
    prediction = "✅ Eligible";
  } else if (creditHistory === 1 && totalIncome > 5000 && loanAmount <= 350) {
    prediction = "✅ Eligible";
  }

  res.json({
    status: prediction,
    confidence: creditHistory === 1 ? 0.9 : 0.6,
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));


